const KEY = "categories";

export const getCategories = () => {
  return JSON.parse(localStorage.getItem(KEY)) || [];
};

export const saveCategories = (categories) => {
  localStorage.setItem(KEY, JSON.stringify(categories));
};
