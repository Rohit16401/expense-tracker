const KEY = "transactions";

export const getTransactions = () => {
  return JSON.parse(localStorage.getItem(KEY)) || [];
};

export const saveTransactions = (transactions) => {
  localStorage.setItem(KEY, JSON.stringify(transactions));
};
