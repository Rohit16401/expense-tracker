const Footer = () => {
  return (
    <footer className="footer">
      <p>© 2026 Expense Tracker</p>
    </footer>
  );
};

export default Footer;
