import { NavLink } from "react-router-dom";

const Navbar = () => {
  return (
    <aside className="navbar">
      <NavLink to="/" end>Dashboard</NavLink>
      <NavLink to="/categories">Categories</NavLink>
      <NavLink to="/transactions">Transactions</NavLink>
      <NavLink to="/analysis">Analysis</NavLink>
    </aside>
  );
};

export default Navbar;
