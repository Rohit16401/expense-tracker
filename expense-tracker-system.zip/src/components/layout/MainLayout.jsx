import Header from "./Header";
import Footer from "./Footer";
import Navbar from "./NavBar";
import "../../styles/Global.css"
import { Outlet } from "react-router-dom";

const MainLayout = () => {
  return (
    <div className="app-layout">
      <Header />

      <div className="body-layout">
        <Navbar />
        <main className="content">
          <Outlet />
        </main>
      </div>

      <Footer />
    </div>
  );
};

export default MainLayout;
