import { useState, useEffect } from "react";

function GenericForm({
  fields = [],
  initialData = {},
  onSubmit,
  readOnly = false
}) {
  const [formData, setFormData] = useState({});

  useEffect(() => {
    setFormData(initialData);
  }, [initialData]);

  const handleChange = (name, value) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      {fields.map(field => (
        <div key={field.name} className="form-group">
          <label>{field.label}</label>

          <input
            className="input"
            type={field.type || "text"}
            value={formData[field.name] || ""}
            readOnly={field.readOnly}
            disabled={readOnly}
            onChange={(e) =>
              handleChange(field.name, e.target.value)
            }
          />
        </div>
      ))}

      {!readOnly && (
        <button className="btn" type="submit">
          Save
        </button>
      )}
    </form>
  );
}

export default GenericForm;