function GenericTable({
  data = [],
  columns = [],
  onRowClick,
  selectedRow
}) {
  if (!data.length) return <p>No data available</p>;

  return (
    <table className="table">
      <thead>
        <tr>
          {columns.map(col => (
            <th key={col.key}>{col.label}</th>
          ))}
        </tr>
      </thead>

      <tbody>
        {data.map(row => (
          <tr
            key={row.id || row.categoryId}
            onClick={() => onRowClick?.(row)}
            className={
              selectedRow?.categoryId === row.categoryId
                ? "row-selected"
                : ""
            }
          >
            {columns.map(col => (
              <td key={col.key}>
                {row[col.key]}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default GenericTable;

