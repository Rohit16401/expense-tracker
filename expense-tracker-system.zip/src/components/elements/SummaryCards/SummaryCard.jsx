
function SummaryCard({title,amount,type})
{
    return(<>
     
      <div className={`summary-card ${type}`}>
        <h4>{title}</h4>
        <p>₹{amount}</p>
      </div>
      

    </>);
}

export default SummaryCard