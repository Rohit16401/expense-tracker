
import { useState } from "react";
import GenericModal from "../components/elements/Modals/GenericModal";
import GenericForm from "../components/elements/Modals/GenericForm";
import GenericTable from "../components/elements/Modals/GenericTable";
import { getCategories, saveCategories } from "../utils/categoryStorage";

const categoryFields = [
  { name: "categoryId", label: "Category ID", type: "text", readOnly: true },
  { name: "categoryName", label: "Category Name", type: "text" },
  { name: "intendedMonthlyBudget", label: "Monthly Budget", type: "number" }
];

const categoryColumns = [
  { key: "categoryName", label: "Name" },
  { key: "intendedMonthlyBudget", label: "Budget" }
];

function Categories() {

  const [categories, setCategories] = useState(() => getCategories());
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [mode, setMode] = useState("add");

  const refreshCategories = () => {
    setCategories(getCategories());
  };

  const handleSave = (formData) => {
    const existing = getCategories();
    let updated;

    if (mode === "edit") {
      updated = existing.map(c =>
        c.categoryId === formData.categoryId ? formData : c
      );
    } else {
      const alreadyExists = existing.some(
        c => c.categoryName.toLowerCase() === formData.categoryName.toLowerCase()
      );

      if (alreadyExists) {
        alert("Category already exists");
        return;
      }

      updated = [
        ...existing,
        { ...formData, categoryId: Date.now() }
      ];
    }

    saveCategories(updated);
    refreshCategories();
    setModalOpen(false);
  };

  const openAdd = () => {
    setMode("add");
    setSelectedCategory(null);
    setModalOpen(true);
  };

  const openEdit = () => {
    if (!selectedCategory) {
      alert("Select a category first");
      return;
    }

    setMode("edit");
    setModalOpen(true);
  };

  const openView = () => {
    if (!selectedCategory) {
      alert("Select a category first");
      return;
    }

    setMode("view");
    setModalOpen(true);
  };

  return (
    <div className="page">
      <h2>Categories</h2>

      {/* 🔹 Menu */}
      <div style={styles.menu}>
        <button className="btn" onClick={openAdd}>Add</button>
        <button className="btn-secondary" onClick={openEdit}>Edit</button>
        <button className="btn-secondary" onClick={openView}>View</button>
      </div>

      {/* 🔹 Generic Table */}
      <GenericTable
        data={categories}
        columns={categoryColumns}
        onRowClick={setSelectedCategory}
        selectedRow={selectedCategory}
      />

      {/* 🔹 Generic Modal */}
      <GenericModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={
          mode === "add"
            ? "Add Category"
            : mode === "edit"
            ? "Edit Category"
            : "View Category"
        }
      >
        <GenericForm
          key={selectedCategory?.categoryId || "new"}
          fields={categoryFields}
          initialData={
            selectedCategory || ""
          }
          onSubmit={handleSave}
          readOnly={mode === "view"}
        />
      </GenericModal>
    </div>
  );
}

const styles = {
  menu: {
    display: "flex",
    gap: "10px",
    margin: "10px 0 20px"
  }
};

export default Categories;
