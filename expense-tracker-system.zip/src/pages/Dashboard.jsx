import SummaryCard from "../components/elements/SummaryCards/SummaryCard";
import PieCharts from "../components/elements/Charts/PieCharts";
import { getTransactions } from "../utils/transactionStorage";
import { useState } from "react";

const Dashboard = () => {
  const [transactions] = useState(() => getTransactions());

  const totalExpense = transactions.reduce(
    (sum, item) => Number(sum) + Number(item.transactionAmount),
    0
  );

  const categoryMap = {};

  transactions.forEach((item) => {
    const category = item.categoryName;
    const amount = Number(item.transactionAmount);

    if (categoryMap[category]) {
      categoryMap[category] += amount;
    } else {
      categoryMap[category] = amount;
    }
  });

  const categoryData = Object.keys(categoryMap).map((key) => ({
    name: key,
    value: categoryMap[key],
  }));

  return (
    <div>
      <h2>Dashboard</h2>

      <div className="summary-grid">
        <SummaryCard type="income" title="Total Income" amount={80000} />
        <SummaryCard type="expense" title="Total Expense" amount={totalExpense} />
        <SummaryCard
          type="balance"
          title="Total Balance"
          amount={80000 - totalExpense}
        />
      </div>

      <section style={{ marginTop: "30px" }}>
        <h3>Recent Transactions :-</h3>

        <ul className="transaction-list">
          {transactions.map((ans) => (
            <li key={ans.id}>
              {ans.categoryName} - ₹{ans.transactionAmount}
            </li>
          ))}
        </ul>
      </section>

      <section style={{ marginTop: "30px" }}>
        <h3>Expense Breakdown</h3>

        <PieCharts
          data={categoryData}
          dataKey="value"
          nameKey="name"
          height={300}
        />
      </section>
    </div>
  );
};

export default Dashboard;
