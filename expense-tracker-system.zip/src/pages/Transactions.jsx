import { useState } from "react";
import GenericModal from "../components/elements/Modals/GenericModal";
import GenericForm from "../components/elements/Modals/GenericForm";
import GenericTable from "../components/elements/Modals/GenericTable";
import { getTransactions,saveTransactions } from "../utils/transactionStorage";

const transactionFields = [
  { name: "transactionId", label: "Transaction ID", type: "text", readOnly: true },
  {name: "type",label:"Type"},
  { name: "categoryName", label: "Category Name", type: "text" },
  { name: "transactionAmount", label: "Transcation Amount", type: "number" },
  { name: "transactionDate", label: "Transaction Date", type: "date" }
];

const transactionColumns = [
  { key: "categoryName", label: "Category Type" },
  {key: "transactionDate", label: "Transcation Date"},
  {key: "type",label:"Type"},
  { key: "transactionAmount", label: "Transcation Amount" }
];

function Transactions() {

  const [transactions, settransactions] = useState(() => getTransactions());
  const [selectedTransaction, setselectedTransaction] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [mode, setMode] = useState("add");

  const refreshtransactions = () => {
    settransactions(getTransactions());
  };

  const handleSave = (formData) => {
    const existing = getTransactions();
    let updated;

    if (mode === "edit") {
      updated = existing.map(c =>
        c.transactionId === formData.transactionId ? formData : c
      );
    } else {
      const alreadyExists = existing.some(
        c => c.categoryName.toLowerCase() === formData.categoryName.toLowerCase()
      );

      if (alreadyExists) {
        alert("Category already exists");
        return;
      }

      updated = [
        ...existing,
        { ...formData, transactionId: Date.now() }
      ];
    }

    saveTransactions(updated);
    refreshtransactions();
    setModalOpen(false);
  };

  const openAdd = () => {
    setMode("add");
    setselectedTransaction(null);
    setModalOpen(true);
  };

  const openEdit = () => {
    if (!selectedTransaction) {
      alert("Select a transaction first");
      return;
    }

    setMode("edit");
    setModalOpen(true);
  };

  const openView = () => {
    if (!selectedTransaction) {
      alert("Select a transaction first");
      return;
    }

    setMode("view");
    setModalOpen(true);
  };

  return (
    <div className="page">
      <h2>Transactions</h2>

      <div style={styles.menu}>
        <button className="btn" onClick={openAdd}>Add</button>
        <button className="btn-secondary" onClick={openEdit}>Edit</button>
        <button className="btn-secondary" onClick={openView}>View</button>
      </div>

      <GenericTable
        data={transactions}
        columns={transactionColumns}
        onRowClick={setselectedTransaction}
        selectedRow={selectedTransaction}
      />

      <GenericModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={
          mode === "add"
            ? "Add Transcation"
            : mode === "edit"
            ? "Edit Transcation"
            : "View Transcation"
        }
      >
        <GenericForm
          key={selectedTransaction?.transactionId || "new"}
          fields={transactionFields}
          initialData={
            selectedTransaction || ""
          }
          onSubmit={handleSave}
          readOnly={mode === "view"}
        />
      </GenericModal>
    </div>
  );
}

const styles = {
  menu: {
    display: "flex",
    gap: "10px",
    margin: "10px 0 20px"
  }
};

export default Transactions;
